package guru.springframework.sgfdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgfDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
